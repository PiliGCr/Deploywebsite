Todo list 3 practice deployment. 
